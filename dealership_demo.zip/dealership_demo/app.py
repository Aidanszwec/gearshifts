from flask import Flask, request, jsonify
import os
import json
from groq import Groq

# Set environment variable for Groq API Key
os.environ["GROQ_API_KEY"] = "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"

# Initialize the Groq client
client = Groq(
    api_key=os.environ.get("GROQ_API_KEY"),
)

# Set environment variable for Groq API Key
os.environ["GROQ_API_KEY"] = "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"

# Initialize the Groq client
client = Groq(api_key=os.environ.get("GROQ_API_KEY"))

app = Flask(__name__)

@app.route('/chat', methods=['POST'])
def chat():
    # Get the user message from the frontend
    user_message = request.json.get('message')

    # Create the request for Groq API to process the user input
    try:
        # Groq API request
        response = client.complete(user_message)
        ai_response = response['choices'][0]['text'].strip()
        
        return jsonify({'response': ai_response})
    
    except Exception as e:
        return jsonify({'response': f"Error: {str(e)}"})

if __name__ == '__main__':
    app.run(debug=True)
